// ============================================
// Arcade Corner — game registry
// Add a new game by adding one object here.
// That's the only place the homepage looks.
// ============================================

const GAMES = [
  {
    id: "snake",
    title: "Snake",
    description: "Grow as long as you can without hitting yourself or the wall.",
    color: "#35e2c2",
    emoji: "🐍",
    folder: "games/snake/index.html"
  },
  {
    id: "memory",
    title: "Memory Match",
    description: "Flip the cards and find every matching pair in the fewest tries.",
    color: "#ff4f81",
    emoji: "🧠",
    folder: "games/memory/index.html"
  },
  {
    id: "tictactoe",
    title: "Tic-Tac-Toe",
    description: "Classic two-player X's and O's. Pass the keyboard to a friend.",
    color: "#ffc94a",
    emoji: "❌",
    folder: "games/tictactoe/index.html"
  }
];

const grid = document.getElementById('grid');
const statusEl = document.getElementById('status');
const restartBtn = document.getElementById('restart');

const LINES = [
  [0,1,2],[3,4,5],[6,7,8],
  [0,3,6],[1,4,7],[2,5,8],
  [0,4,8],[2,4,6]
];

let board, turn, over;

function reset() {
  board = Array(9).fill(null);
  turn = 'X';
  over = false;
  statusEl.textContent = "X's turn";
  grid.innerHTML = '';
  board.forEach((_, i) => {
    const cell = document.createElement('div');
    cell.className = 'cell';
    cell.dataset.index = i;
    cell.addEventListener('click', () => play(i, cell));
    grid.appendChild(cell);
  });
}

function play(i, cell) {
  if (over || board[i]) return;
  board[i] = turn;
  cell.textContent = turn;
  cell.classList.add(turn.toLowerCase());

  const winLine = LINES.find(line => line.every(idx => board[idx] === turn));
  if (winLine) {
    over = true;
    statusEl.textContent = `${turn} wins!`;
    winLine.forEach(idx => grid.children[idx].classList.add('win'));
    return;
  }

  if (board.every(Boolean)) {
    over = true;
    statusEl.textContent = "It's a draw";
    return;
  }

  turn = turn === 'X' ? 'O' : 'X';
  statusEl.textContent = `${turn}'s turn`;
}

restartBtn.addEventListener('click', reset);

reset();

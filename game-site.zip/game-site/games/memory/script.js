const ICONS = ['🍕','🎈','🚀','🐙','🎧','🌵','🍩','⚡'];
const grid = document.getElementById('grid');
const movesEl = document.getElementById('moves');
const pairsEl = document.getElementById('pairs');
const restartBtn = document.getElementById('restart');

let cards, flipped, matchedCount, moves, lock;

function shuffle(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function reset() {
  cards = shuffle([...ICONS, ...ICONS]);
  flipped = [];
  matchedCount = 0;
  moves = 0;
  lock = false;
  movesEl.textContent = moves;
  pairsEl.textContent = matchedCount;

  grid.innerHTML = '';
  cards.forEach((icon, i) => {
    const tile = document.createElement('div');
    tile.className = 'tile';
    tile.dataset.icon = icon;
    tile.dataset.index = i;
    tile.addEventListener('click', () => flipTile(tile));
    grid.appendChild(tile);
  });
}

function flipTile(tile) {
  if (lock) return;
  if (tile.classList.contains('flipped') || tile.classList.contains('matched')) return;
  if (flipped.length === 2) return;

  tile.classList.add('flipped');
  tile.textContent = tile.dataset.icon;
  flipped.push(tile);

  if (flipped.length === 2) {
    moves++;
    movesEl.textContent = moves;
    const [a, b] = flipped;
    if (a.dataset.icon === b.dataset.icon) {
      a.classList.add('matched');
      b.classList.add('matched');
      flipped = [];
      matchedCount++;
      pairsEl.textContent = matchedCount;
      if (matchedCount === ICONS.length) {
        setTimeout(() => alert(`Solved in ${moves} moves!`), 200);
      }
    } else {
      lock = true;
      setTimeout(() => {
        a.classList.remove('flipped');
        b.classList.remove('flipped');
        a.textContent = '';
        b.textContent = '';
        flipped = [];
        lock = false;
      }, 700);
    }
  }
}

restartBtn.addEventListener('click', reset);

reset();
